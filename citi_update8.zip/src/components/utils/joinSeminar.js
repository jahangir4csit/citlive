import React from "react"
import { Link } from "gatsby"

const JoinSeminar = ()=>{
    return(
        <div class="side_text">
            <Link to="/free-seminar">জয়েন ফ্রি সেমিনার</Link>
        </div>
    )
}
export default JoinSeminar;
