import React from "react"
import Seo from "../components/seo"
import Layout from "../components/layout"

const StudentLogin = () => (
  <Layout>
      <main>
        <h1>StudentLogin</h1>
        <p>Welcome to my StudentLogin </p>
      </main>
  </Layout>
)

export default StudentLogin