import * as React from "react"

export default function CourseCats () {
  return "Hello world"
}